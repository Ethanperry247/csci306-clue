// Authors: Caleb Pan, Ethan Perry

package clueGame;

public enum DoorDirection { 
    UP,
    DOWN,
    LEFT,
    RIGHT,
    NONE;
	
}