// Authors: Caleb Pan, Ethan Perry

package clueGame;

public enum CardType {
	PERSON,
	WEAPON,
	ROOM;
}
