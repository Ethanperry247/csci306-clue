// Authors: Caleb Pan, Ethan Perry

package clueGame;

import java.awt.Color;

public class HumanPlayer extends Player {

	public HumanPlayer(String playerName, int row, int column, String color) {
		super(playerName, row, column, color);
		// TODO Auto-generated constructor stub
	}

}
